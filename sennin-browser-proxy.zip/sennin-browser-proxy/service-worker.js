self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open('sennin-proxy-cache-v1').then((cache) => {
      return cache.addAll(['/', '/public/style.css', '/scripts/main.js']);
    })
  );
});

self.addEventListener('fetch', (e) => {
  e.respondWith(
    caches.match(e.request).then((r) => {
      return r || fetch(e.request);
    })
  );
});
