const express = require('express');
const path = require('path');
const axios = require('axios');
const app = express();
const PORT = process.env.PORT || 3000;

app.use('/public', express.static(path.join(__dirname, 'public')));
app.use('/scripts', express.static(path.join(__dirname, 'scripts')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Proxy endpoint to bypass CORS and iframe restrictions
app.get('/proxy', async (req, res) => {
  try {
    const targetUrl = req.query.url;
    if (!targetUrl) {
      return res.status(400).send('URL parameter is required');
    }

    // Basic validation: allow only http and https URLs
    if (!/^https?:\/\//i.test(targetUrl)) {
      return res.status(400).send('Invalid URL');
    }

    // Fetch content from target URL
    const response = await axios.get(targetUrl, {
      responseType: 'arraybuffer',
      headers: {
        'User-Agent': 'SenninBrowserProxy/1.0',
      },
    });

    // Copy content-type header from response
    const contentType = response.headers['content-type'] || 'text/html';

    // Send response with original content type
    res.set('Content-Type', contentType);
    res.send(response.data);
  } catch (error) {
    console.error('Proxy error:', error.message);
    res.status(500).send('Proxy error: ' + error.message);
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
