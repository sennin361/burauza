# Sennin Browser Proxy

仙人ブラウザーのプロキシ対応版です。  
これによりCORSやiframe制限がかかるサイトでも閲覧しやすくなっています。

## 起動方法

```bash
npm install
npm start
```
