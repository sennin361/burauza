const backBtn = document.getElementById('backBtn');
const forwardBtn = document.getElementById('forwardBtn');
const searchBtn = document.getElementById('searchBtn');
const urlInput = document.getElementById('urlInput');
const engineSelect = document.getElementById('engineSelect');
const toggleSidebar = document.getElementById('toggleSidebar');
const sidebar = document.getElementById('sidebar');
const historyList = document.getElementById('historyList');
const clearHistoryBtn = document.getElementById('clearHistory');
const webview = document.getElementById('webview');

let historyArr = [];
let historyIndex = -1;

function updateHistoryList() {
  historyList.innerHTML = '';
  historyArr.forEach((url, idx) => {
    const li = document.createElement('li');
    li.textContent = url;
    li.onclick = () => loadURL(url, false);
    if (idx === historyIndex) {
      li.style.fontWeight = 'bold';
    }
    historyList.appendChild(li);
  });
}

function proxyURL(url) {
  return '/proxy?url=' + encodeURIComponent(url);
}

function loadURL(url, push = true) {
  if (push) {
    historyArr = historyArr.slice(0, historyIndex + 1);
    historyArr.push(url);
    historyIndex = historyArr.length - 1;
    updateHistoryList();
  }
  webview.src = proxyURL(url);
  urlInput.value = url;
}

searchBtn.onclick = () => {
  let query = urlInput.value.trim();
  if (!query) return;
  const prefix = engineSelect.value;
  const url = query.startsWith('http') ? query : prefix + encodeURIComponent(query);
  loadURL(url);
};

backBtn.onclick = () => {
  if (historyIndex > 0) {
    historyIndex--;
    loadURL(historyArr[historyIndex], false);
  }
};

forwardBtn.onclick = () => {
  if (historyIndex < historyArr.length - 1) {
    historyIndex++;
    loadURL(historyArr[historyIndex], false);
  }
};

toggleSidebar.onclick = () => {
  sidebar.classList.toggle('hidden');
};

clearHistoryBtn.onclick = () => {
  historyArr = [];
  historyIndex = -1;
  updateHistoryList();
};
